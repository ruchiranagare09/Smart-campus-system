#include "RoomLighting.h"
#include "InputHelper.h"
#include <iostream>

using namespace std;

RoomLighting::RoomLighting(int id, const string& name, const string& mfr, int brightness)
    : Device(id, name, mfr), brightnessLevel(brightness) {}

void RoomLighting::InteractionEvent() {
    if (!status) {
        cout << "  [!] Cannot adjust lighting. " << deviceName << " is inactive.\n";
        return;
    }
    cout << "Current brightness level: " << brightnessLevel << "\n";
    brightnessLevel = InputHelper::getIntInRange("Enter new brightness level (0-100): ", 0, 100);
    cout << "Brightness set to " << brightnessLevel << "\n";
    notifyObservers("Brightness changed to " + to_string(brightnessLevel));
}

void RoomLighting::ViewInfo() const {
    Device::ViewInfo();
    cout << "Brightness Level : " << brightnessLevel << "\n";
    cout << string(50, '=') << "\n";
}

string RoomLighting::getType()      const { return "RoomLighting"; }

string RoomLighting::toFileString() const {
    return "RoomLighting," + to_string(deviceID) + "," + deviceName + "," +
           manufacturer + "," + to_string(brightnessLevel);
}

void RoomLighting::editAttributes() {
    brightnessLevel = InputHelper::getIntInRange(
        "Edit Brightness Level (current: " + to_string(brightnessLevel) + "): ", 0, 100);
    cout << "Brightness level updated.\n";
    notifyObservers("Attributes edited");
}

shared_ptr<Device> RoomLighting::clone(int newID) const {
    return make_shared<RoomLighting>(newID, deviceName + "_copy", manufacturer, brightnessLevel);
}
