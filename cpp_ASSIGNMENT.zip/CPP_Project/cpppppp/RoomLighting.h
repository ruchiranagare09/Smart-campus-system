#pragma once
#include "Device.h"

using namespace std;

// ─────────────────────────────────────────────
//  RoomLighting device
// ─────────────────────────────────────────────

class RoomLighting : public Device {
private:
    int brightnessLevel;

public:
    RoomLighting(int id, const string& name, const string& mfr, int brightness);

    void   InteractionEvent()           override;
    void   ViewInfo()             const override;
    string getType()              const override;
    string toFileString()         const override;
    void   editAttributes()             override;
    shared_ptr<Device> clone(int newID) const override;
};
