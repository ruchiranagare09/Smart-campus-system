#include "Room.h"
#include <iostream>
#include <algorithm>

using namespace std;

Room::Room(const string& name) : roomName(name) {}

string Room::getName()            const { return roomName; }
void   Room::setName(const string& n)   { roomName = n; }

void Room::addDevice(shared_ptr<Device> device) {
    devices.push_back(device);
}

bool Room::removeDevice(int deviceID) {
    auto it = remove_if(devices.begin(), devices.end(),
        [deviceID](const shared_ptr<Device>& d) { return d->getID() == deviceID; });
    if (it != devices.end()) {
        devices.erase(it, devices.end());
        return true;
    }
    return false;
}

vector<shared_ptr<Device>>&       Room::getDevices()       { return devices; }
const vector<shared_ptr<Device>>& Room::getDevices() const { return devices; }

void Room::activateAll() {
    cout << "\nActivating all devices in " << roomName << "...\n";
    for (auto& d : devices) d->Activate();
}

void Room::deactivateAll() {
    cout << "\nDeactivating all devices in " << roomName << "...\n";
    for (auto& d : devices) d->Deactivate();
}

void Room::listDevices() const {
    if (devices.empty()) {
        cout << "No devices in this room.\n";
        return;
    }
    cout << "\n--- Devices in " << roomName << " ---\n";
    for (size_t i = 0; i < devices.size(); i++) {
        cout << i + 1 << ". ID:" << devices[i]->getID()
             << " - " << devices[i]->getName()
             << " (" << devices[i]->getType() << ")"
             << " - " << (devices[i]->getStatus() ? "Active" : "Inactive") << "\n";
    }
}
