#include "SmartCampusSystem.h"

// ─────────────────────────────────────────────
//  Entry point
//  Singleton Pattern: obtain the single instance
// ─────────────────────────────────────────────

int main() {
    SmartCampusSystem& system = SmartCampusSystem::getInstance();
    system.mainMenu();
    return 0;
}
