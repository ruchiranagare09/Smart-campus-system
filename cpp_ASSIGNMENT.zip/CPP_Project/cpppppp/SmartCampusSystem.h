#pragma once
#include "Device.h"
#include "Room.h"
#include "DeviceCommand.h"
#include "FileStrategy.h"
#include <vector>
#include <memory>

using namespace std;

// ─────────────────────────────────────────────
//  SmartCampusSystem  –  Singleton Pattern
// ─────────────────────────────────────────────

class SmartCampusSystem {
private:
    vector<shared_ptr<Device>> allDevices;
    vector<Room>               rooms;
    shared_ptr<DeviceObserver> logger;
    unique_ptr<FileStrategy>   fileStrategy;
    CommandInvoker             commandInvoker;

    // Singleton: private constructor
    SmartCampusSystem();
    SmartCampusSystem(const SmartCampusSystem&)            = delete;
    SmartCampusSystem& operator=(const SmartCampusSystem&) = delete;

    // Helpers
    int                 getNextID()                    const;
    bool                isIDDuplicate(int id)          const;
    shared_ptr<Device>  findDeviceByID(int id);
    Room*               findRoomByName(const string& name);

    // Device management internals
    void addDeviceToRoom(shared_ptr<Device> device);

    // Room management internals
    void createRoom();
    void listRooms()            const;
    void viewRoomDevices();
    void addDeviceToRoomMenu();
    void removeDeviceFromRoom();
    void activateRoomDevices();
    void deactivateRoomDevices();
    void duplicateRoom();

public:
    static SmartCampusSystem& getInstance();
    ~SmartCampusSystem();

    void loadFromFile();
    void saveToFile();

    // Public menus
    void mainMenu();
    void manageRooms();

    // Public actions
    void addDevice();
    void deleteDevice();
    void editDevice();
    void listAllDevices()       const;
    void individualDeviceMenu();
    void performActionOnAll();
    void viewConnectionStatus() const;
    void changeConnectionStatus();
    void searchDevice();
    void viewCommandHistory();
};
