#include "Projector.h"
#include "InputHelper.h"
#include <iostream>
#include <algorithm>

using namespace std;

Projector::Projector(int id, const string& name, const string& mfr,
                     const string& inp, int brightness)
    : Device(id, name, mfr), input(inp), brightnessLevel(brightness) {}

void Projector::InteractionEvent() {
    if (!status) {
        cout << "  [!] Cannot adjust projector. " << deviceName << " is inactive.\n";
        return;
    }
    cout << "\n--- Projector Settings ---\n";
    cout << "1. Change Input Source (current: " << input << ")\n";
    cout << "2. Change Brightness   (current: " << brightnessLevel << ")\n";
    cout << "3. Change Both\n";

    int choice = InputHelper::getIntInRange("Choice: ", 1, 3);

    if (choice == 1 || choice == 3) {
        input = InputHelper::getString("Enter input source (VGA/HDMI/Wireless): ");
    }
    if (choice == 2 || choice == 3) {
        brightnessLevel = InputHelper::getIntInRange("Enter brightness level (0-100): ", 0, 100);
    }
    cout << "Projector settings updated.\n";
    notifyObservers("Projector settings changed");
}

void Projector::ViewInfo() const {
    Device::ViewInfo();
    cout << "Input Source     : " << input          << "\n";
    cout << "Brightness Level : " << brightnessLevel << "\n";
    cout << string(50, '=') << "\n";
}

string Projector::getType()      const { return "Projector"; }

string Projector::toFileString() const {
    return "Projector," + to_string(deviceID) + "," + deviceName + "," +
           manufacturer + "," + input + "," + to_string(brightnessLevel);
}

void Projector::editAttributes() {
    input           = InputHelper::getString("Edit Input Source (current: " + input + "): ");
    brightnessLevel = InputHelper::getIntInRange(
        "Edit Brightness Level (current: " + to_string(brightnessLevel) + "): ", 0, 100);
    cout << "Attributes updated.\n";
    notifyObservers("Attributes edited");
}

shared_ptr<Device> Projector::clone(int newID) const {
    return make_shared<Projector>(newID, deviceName + "_copy", manufacturer, input, brightnessLevel);
}
