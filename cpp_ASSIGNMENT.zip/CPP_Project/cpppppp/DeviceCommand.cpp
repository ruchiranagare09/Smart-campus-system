#include "DeviceCommand.h"
#include <iostream>

using namespace std;

// ─── ActivateCommand ─────────────────────────
ActivateCommand::ActivateCommand(shared_ptr<Device> dev) : device(dev) {}
void   ActivateCommand::execute()              { device->Activate(); }
string ActivateCommand::getDescription() const { return "Activate " + device->getName(); }

// ─── DeactivateCommand ───────────────────────
DeactivateCommand::DeactivateCommand(shared_ptr<Device> dev) : device(dev) {}
void   DeactivateCommand::execute()              { device->Deactivate(); }
string DeactivateCommand::getDescription() const { return "Deactivate " + device->getName(); }

// ─── InteractCommand ─────────────────────────
InteractCommand::InteractCommand(shared_ptr<Device> dev) : device(dev) {}
void   InteractCommand::execute()              { device->InteractionEvent(); }
string InteractCommand::getDescription() const { return "Interact with " + device->getName(); }

// ─── CommandInvoker ──────────────────────────
void CommandInvoker::executeCommand(shared_ptr<DeviceCommand> command) {
    command->execute();
    commandHistory.push_back(command);
}

void CommandInvoker::showHistory() const {
    cout << "\n--- Command History ---\n";
    if (commandHistory.empty()) {
        cout << "No commands executed yet.\n";
        return;
    }
    for (size_t i = 0; i < commandHistory.size(); i++) {
        cout << i + 1 << ". " << commandHistory[i]->getDescription() << "\n";
    }
}
