#include "DeviceFactory.h"
#include "SecurityCamera.h"
#include "AirConditioning.h"
#include "Projector.h"
#include "RoomLighting.h"
#include "DoorLock.h"
#include "InputHelper.h"

using namespace std;

shared_ptr<Device> DeviceFactory::createDevice(const string& type,
                                               int id,
                                               const string& name,
                                               const string& mfr,
                                               const vector<string>& params) {
    if (type == "SecurityCamera") {
        string quality = params.size() > 0 ? params[0] : "1080p";
        string power   = params.size() > 1 ? params[1] : "Mains";
        return make_shared<SecurityCamera>(id, name, mfr, quality, power);
    }
    else if (type == "AirConditioning") {
        double temp = 22.0;
        if (params.size() > 0) InputHelper::tryParseDouble(params[0], temp);
        return make_shared<AirConditioning>(id, name, mfr, temp);
    }
    else if (type == "Projector") {
        string inp        = params.size() > 0 ? params[0] : "HDMI";
        int    brightness = 50;
        if (params.size() > 1) InputHelper::tryParseInt(params[1], brightness);
        return make_shared<Projector>(id, name, mfr, inp, brightness);
    }
    else if (type == "RoomLighting") {
        int brightness = 50;
        if (params.size() > 0) InputHelper::tryParseInt(params[0], brightness);
        return make_shared<RoomLighting>(id, name, mfr, brightness);
    }
    else if (type == "DoorLock") {
        bool   locked   = params.size() > 0 && params[0] == "1";
        string lastUser = params.size() > 1 ? params[1] : "System";
        return make_shared<DoorLock>(id, name, mfr, locked, lastUser);
    }

    return nullptr;
}
