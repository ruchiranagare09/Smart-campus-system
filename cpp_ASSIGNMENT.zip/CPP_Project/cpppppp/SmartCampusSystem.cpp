#include "SmartCampusSystem.h"
#include "DeviceFactory.h"
#include "InputHelper.h"
#include <iostream>
#include <algorithm>
#include <memory>

using namespace std;

// ─────────────────────────────────────────────
//  Constructor / Destructor
// ─────────────────────────────────────────────

SmartCampusSystem::SmartCampusSystem() {
    logger       = make_shared<DeviceLogger>();
    fileStrategy = unique_ptr<FileStrategy>(new TextFileStrategy());
    loadFromFile();
}

SmartCampusSystem::~SmartCampusSystem() {
    saveToFile();
}

SmartCampusSystem& SmartCampusSystem::getInstance() {
    static SmartCampusSystem instance;
    return instance;
}

// ─────────────────────────────────────────────
//  File I/O
// ─────────────────────────────────────────────

void SmartCampusSystem::loadFromFile() {
    fileStrategy->load("campus_data.txt", allDevices, rooms);
    for (auto& d : allDevices) d->attachObserver(logger);
}

void SmartCampusSystem::saveToFile() {
    fileStrategy->save("campus_data.txt", allDevices, rooms);
}

// ─────────────────────────────────────────────
//  Helpers
// ─────────────────────────────────────────────

int SmartCampusSystem::getNextID() const {
    int maxID = 0;
    for (const auto& d : allDevices)
        if (d->getID() > maxID) maxID = d->getID();
    return maxID + 1;
}

bool SmartCampusSystem::isIDDuplicate(int id) const {
    return any_of(allDevices.begin(), allDevices.end(),
        [id](const shared_ptr<Device>& d) { return d->getID() == id; });
}

shared_ptr<Device> SmartCampusSystem::findDeviceByID(int id) {
    auto it = find_if(allDevices.begin(), allDevices.end(),
        [id](const shared_ptr<Device>& d) { return d->getID() == id; });
    return (it != allDevices.end()) ? *it : nullptr;
}

Room* SmartCampusSystem::findRoomByName(const string& name) {
    auto it = find_if(rooms.begin(), rooms.end(),
        [&name](const Room& r) { return r.getName() == name; });
    return (it != rooms.end()) ? &(*it) : nullptr;
}

// ─────────────────────────────────────────────
//  Device Management
// ─────────────────────────────────────────────

void SmartCampusSystem::addDevice() {
    cout << "\n--- Add New Device ---\n";
    cout << "1. Security Camera\n2. Air Conditioning\n3. Projector\n";
    cout << "4. Room Lighting\n5. Door Lock\n";

    int choice = InputHelper::getIntInRange("Choice: ", 1, 5);
    int id     = InputHelper::getInt("Enter Device ID: ");

    if (isIDDuplicate(id)) {
        cout << "  [!] Error: Device ID " << id << " already exists!\n";
        return;
    }

    string name = InputHelper::getString("Enter Device Name: ");
    string mfr  = InputHelper::getString("Enter Manufacturer: ");

    vector<string>     params;
    string             devType;
    shared_ptr<Device> device;

    switch (choice) {
        case 1:
            devType = "SecurityCamera";
            params.push_back(InputHelper::getString("Enter Camera Quality (e.g. 1080p): "));
            params.push_back(InputHelper::getString("Enter Power Source: "));
            break;
        case 2:
            devType = "AirConditioning";
            params.push_back(to_string(InputHelper::getDouble("Enter Target Temperature (C): ")));
            break;
        case 3:
            devType = "Projector";
            params.push_back(InputHelper::getString("Enter Input Source (VGA/HDMI/Wireless): "));
            params.push_back(to_string(InputHelper::getIntInRange("Enter Brightness (0-100): ", 0, 100)));
            break;
        case 4:
            devType = "RoomLighting";
            params.push_back(to_string(InputHelper::getIntInRange("Enter Brightness (0-100): ", 0, 100)));
            break;
        case 5:
            devType = "DoorLock";
            params.push_back(to_string(InputHelper::getIntInRange("Locked? (1=Yes, 0=No): ", 0, 1)));
            params.push_back(InputHelper::getString("Last Opened By: "));
            break;
        default:
            cout << "Invalid choice.\n";
            return;
    }

    device = DeviceFactory::createDevice(devType, id, name, mfr, params);

    if (device) {
        device->attachObserver(logger);
        allDevices.push_back(device);

        char addToRoom = InputHelper::getChar("Add to a room? (y/n): ", "yn");
        if (addToRoom == 'y') addDeviceToRoom(device);

        cout << "Device added successfully!\n";
    }
}

void SmartCampusSystem::deleteDevice() {
    if (allDevices.empty()) { cout << "No devices to delete.\n"; return; }

    int id = InputHelper::getInt("Enter Device ID to delete: ");

    auto it = remove_if(allDevices.begin(), allDevices.end(),
        [id](const shared_ptr<Device>& d) { return d->getID() == id; });

    if (it != allDevices.end()) {
        for (auto& room : rooms) room.removeDevice(id);
        allDevices.erase(it, allDevices.end());
        cout << "Device deleted successfully.\n";
    } else {
        cout << "Device not found.\n";
    }
}

void SmartCampusSystem::editDevice() {
    if (allDevices.empty()) { cout << "No devices available.\n"; return; }

    int id     = InputHelper::getInt("Enter Device ID to edit: ");
    auto device = findDeviceByID(id);

    if (!device) { cout << "Device not found.\n"; return; }

    cout << "\nEditing: " << device->getName() << "\n";
    cout << "1. Edit Name\n2. Edit Manufacturer\n";
    cout << "3. Edit Device-Specific Attributes\n4. Edit All\n";

    int choice = InputHelper::getIntInRange("Choice: ", 1, 4);

    if (choice == 1 || choice == 4)
        device->setName(InputHelper::getString("New Name: "));
    if (choice == 2 || choice == 4)
        device->setManufacturer(InputHelper::getString("New Manufacturer: "));
    if (choice == 3 || choice == 4)
        device->editAttributes();

    cout << "Device updated successfully.\n";
}

void SmartCampusSystem::listAllDevices() const {
    if (allDevices.empty()) { cout << "No devices in the system.\n"; return; }

    cout << "\n" << string(70, '=') << "\n";
    cout << "ALL DEVICES IN SYSTEM\n";
    cout << string(70, '=') << "\n";
    for (size_t i = 0; i < allDevices.size(); i++) {
        cout << i + 1
             << ". ID:" << allDevices[i]->getID()
             << " | " << allDevices[i]->getName()
             << " (" << allDevices[i]->getType() << ")"
             << " | " << (allDevices[i]->getStatus()           ? "Active"    : "Inactive")
             << " | " << (allDevices[i]->getConnectionStatus() ? "Connected" : "Disconnected")
             << "\n";
    }
    cout << string(70, '=') << "\n";
}

void SmartCampusSystem::individualDeviceMenu() {
    if (allDevices.empty()) { cout << "No devices available.\n"; return; }

    listAllDevices();
    int id = InputHelper::getInt("\nEnter Device ID: ");
    auto device = findDeviceByID(id);
    if (!device) { cout << "Device not found.\n"; return; }

    while (true) {
        cout << "\n--- Device: " << device->getName() << " ---\n";
        cout << "1. View Info\n2. Activate\n3. Deactivate\n4. Interact\n";
        cout << "5. Check Connection\n0. Back\n";

        int choice = InputHelper::getIntInRange("Choice: ", 0, 5);
        switch (choice) {
            case 1: device->ViewInfo(); break;
            case 2: commandInvoker.executeCommand(make_shared<ActivateCommand>(device));   break;
            case 3: commandInvoker.executeCommand(make_shared<DeactivateCommand>(device)); break;
            case 4: commandInvoker.executeCommand(make_shared<InteractCommand>(device));   break;
            case 5:
                cout << device->getName() << " is "
                     << (device->CheckConnection() ? "Connected" : "Disconnected") << "\n";
                break;
            case 0: return;
        }
    }
}

void SmartCampusSystem::performActionOnAll() {
    if (allDevices.empty()) { cout << "No devices in the system.\n"; return; }

    cout << "\n--- Perform Action on All Devices ---\n";
    cout << "1. View Info\n2. Activate\n3. Deactivate\n4. Interact\n";

    int choice = InputHelper::getIntInRange("Choice: ", 1, 4);

    for (auto& device : allDevices) {
        switch (choice) {
            case 1: device->ViewInfo(); break;
            case 2: commandInvoker.executeCommand(make_shared<ActivateCommand>(device));   break;
            case 3: commandInvoker.executeCommand(make_shared<DeactivateCommand>(device)); break;
            case 4: commandInvoker.executeCommand(make_shared<InteractCommand>(device));   break;
        }
    }
}

void SmartCampusSystem::viewConnectionStatus() const {
    cout << "\n--- CONNECTED DEVICES ---\n";
    int conn = 0;
    for (const auto& d : allDevices)
        if (d->CheckConnection()) { cout << "ID:" << d->getID() << " - " << d->getName() << "\n"; conn++; }

    cout << "\n--- DISCONNECTED DEVICES ---\n";
    int disc = 0;
    for (const auto& d : allDevices)
        if (!d->CheckConnection()) { cout << "ID:" << d->getID() << " - " << d->getName() << "\n"; disc++; }

    cout << "\nTotal Connected: " << conn << "  |  Total Disconnected: " << disc << "\n";
}

void SmartCampusSystem::changeConnectionStatus() {
    int id = InputHelper::getInt("Enter Device ID to change connection: ");
    auto device = findDeviceByID(id);
    if (device) {
        device->setConnectionStatus(!device->CheckConnection());
        cout << "Connection status changed to "
             << (device->CheckConnection() ? "Connected" : "Disconnected") << "\n";
    } else {
        cout << "Device not found.\n";
    }
}

void SmartCampusSystem::searchDevice() {
    cout << "\nSearch by:\n1. Device ID\n2. Device Name\n";
    int choice = InputHelper::getIntInRange("Choice: ", 1, 2);

    shared_ptr<Device> found = nullptr;

    if (choice == 1) {
        int id = InputHelper::getInt("Enter Device ID: ");
        found  = findDeviceByID(id);
    } else {
        string name = InputHelper::getString("Enter Device Name: ");
        auto it = find_if(allDevices.begin(), allDevices.end(),
            [&name](const shared_ptr<Device>& d) {
                return d->getName().find(name) != string::npos;
            });
        if (it != allDevices.end()) found = *it;
    }

    if (!found) { cout << "Device not found.\n"; return; }

    cout << "\nDevice found!\n";
    while (true) {
        cout << "\n--- " << found->getName() << " ---\n";
        cout << "1. View Info\n2. Activate\n3. Deactivate\n4. Interact\n";
        cout << "5. Check Connection\n0. Back\n";

        int action = InputHelper::getIntInRange("Choice: ", 0, 5);
        switch (action) {
            case 1: found->ViewInfo(); break;
            case 2: commandInvoker.executeCommand(make_shared<ActivateCommand>(found));   break;
            case 3: commandInvoker.executeCommand(make_shared<DeactivateCommand>(found)); break;
            case 4: commandInvoker.executeCommand(make_shared<InteractCommand>(found));   break;
            case 5:
                cout << found->getName() << " is "
                     << (found->CheckConnection() ? "Connected" : "Disconnected") << "\n";
                break;
            case 0: return;
        }
    }
}

void SmartCampusSystem::viewCommandHistory() {
    commandInvoker.showHistory();
}

// ─────────────────────────────────────────────
//  Room Management
// ─────────────────────────────────────────────

void SmartCampusSystem::createRoom() {
    string roomName = InputHelper::getString("Enter Room Name: ");
    if (findRoomByName(roomName)) { cout << "Room already exists.\n"; return; }
    rooms.push_back(Room(roomName));
    cout << "Room '" << roomName << "' created.\n";
}

void SmartCampusSystem::listRooms() const {
    if (rooms.empty()) { cout << "No rooms in the system.\n"; return; }
    cout << "\n--- ROOMS ---\n";
    for (size_t i = 0; i < rooms.size(); i++) {
        cout << i + 1 << ". " << rooms[i].getName()
             << " (" << rooms[i].getDevices().size() << " devices)\n";
    }
}

void SmartCampusSystem::viewRoomDevices() {
    if (rooms.empty()) { cout << "No rooms available.\n"; return; }
    listRooms();
    int roomNum = InputHelper::getIntInRange("Select room number: ", 1, (int)rooms.size());
    rooms[roomNum - 1].listDevices();
}

void SmartCampusSystem::addDeviceToRoom(shared_ptr<Device> device) {
    if (rooms.empty()) { cout << "No rooms available. Create a room first.\n"; return; }
    cout << "\n--- Available Rooms ---\n";
    for (size_t i = 0; i < rooms.size(); i++)
        cout << i + 1 << ". " << rooms[i].getName() << "\n";

    int roomChoice = InputHelper::getIntInRange("Select room number: ", 1, (int)rooms.size());
    rooms[roomChoice - 1].addDevice(device);
    cout << "Device added to " << rooms[roomChoice - 1].getName() << "\n";
}

void SmartCampusSystem::addDeviceToRoomMenu() {
    if (rooms.empty()) { cout << "No rooms available. Create a room first.\n"; return; }
    listAllDevices();
    int id     = InputHelper::getInt("Enter Device ID to add: ");
    auto device = findDeviceByID(id);
    if (!device) { cout << "Device not found.\n"; return; }
    addDeviceToRoom(device);
}

void SmartCampusSystem::removeDeviceFromRoom() {
    if (rooms.empty()) { cout << "No rooms available.\n"; return; }
    listRooms();
    int roomNum = InputHelper::getIntInRange("Select room number: ", 1, (int)rooms.size());
    rooms[roomNum - 1].listDevices();
    int id = InputHelper::getInt("Enter Device ID to remove: ");
    if (rooms[roomNum - 1].removeDevice(id))
        cout << "Device removed from room.\n";
    else
        cout << "Device not found in this room.\n";
}

void SmartCampusSystem::activateRoomDevices() {
    if (rooms.empty()) { cout << "No rooms available.\n"; return; }
    listRooms();
    int roomNum = InputHelper::getIntInRange("Select room number: ", 1, (int)rooms.size());
    rooms[roomNum - 1].activateAll();
}

void SmartCampusSystem::deactivateRoomDevices() {
    if (rooms.empty()) { cout << "No rooms available.\n"; return; }
    listRooms();
    int roomNum = InputHelper::getIntInRange("Select room number: ", 1, (int)rooms.size());
    rooms[roomNum - 1].deactivateAll();
}

void SmartCampusSystem::duplicateRoom() {
    if (rooms.empty()) { cout << "No rooms to duplicate.\n"; return; }
    listRooms();
    int roomNum = InputHelper::getIntInRange("Select room number to duplicate: ", 1, (int)rooms.size());

    Room& originalRoom = rooms[roomNum - 1];
    string newRoomName = originalRoom.getName() + "_copy";
    Room   newRoom(newRoomName);

    // Prototype Pattern: clone each device with a fresh ID
    for (const auto& device : originalRoom.getDevices()) {
        int newID = getNextID();
        shared_ptr<Device> newDevice = device->clone(newID);
        newDevice->attachObserver(logger);
        allDevices.push_back(newDevice);
        newRoom.addDevice(newDevice);
    }

    rooms.push_back(newRoom);
    cout << "Room duplicated as '" << newRoomName << "' with "
         << newRoom.getDevices().size() << " devices.\n";
}

void SmartCampusSystem::manageRooms() {
    while (true) {
        cout << "\n------------------------------------------------\n";
        cout << "|              ROOM MANAGEMENT                 |\n";
        cout << "------------------------------------------------\n";
        cout << "1. Create Room\n2. List All Rooms\n3. View Devices in Room\n";
        cout << "4. Add Device to Room\n5. Remove Device from Room\n";
        cout << "6. Activate All Devices in Room\n7. Deactivate All Devices in Room\n";
        cout << "8. Duplicate Room\n0. Back\n";

        int choice = InputHelper::getIntInRange("Choice: ", 0, 8);
        switch (choice) {
            case 1: createRoom();            break;
            case 2: listRooms();             break;
            case 3: viewRoomDevices();       break;
            case 4: addDeviceToRoomMenu();   break;
            case 5: removeDeviceFromRoom();  break;
            case 6: activateRoomDevices();   break;
            case 7: deactivateRoomDevices(); break;
            case 8: duplicateRoom();         break;
            case 0: return;
        }
    }
}

// ─────────────────────────────────────────────
//  Main Menu
// ─────────────────────────────────────────────

void SmartCampusSystem::mainMenu() {
    while (true) {
        cout << "\n\t\t========================================\n";
        cout <<   "\t\t|       Campus Management System       |\n";
        cout <<   "\t\t========================================\n";

        cout << "\n------------------------------------------------\n";
        cout <<   "|            DEVICE MANAGEMENT                 |\n";
        cout <<   "------------------------------------------------\n";
        cout << "1.  List All Devices\n";
        cout << "2.  Add New Device        (Factory Pattern)\n";
        cout << "3.  Delete Device\n";
        cout << "4.  Edit Device\n";
        cout << "5.  Control Individual Device (Command Pattern)\n";
        cout << "6.  Perform Action on All Devices\n";
        cout << "7.  Search for Device\n";

        cout << "\n------------------------------------------------\n";
        cout <<   "|           CONNECTION MANAGEMENT              |\n";
        cout <<   "------------------------------------------------\n";
        cout << "8.  View Connection Status\n";
        cout << "9.  Change Connection Status  (Observer Pattern)\n";

        cout << "\n------------------------------------------------\n";
        cout <<   "|              ROOM MANAGEMENT                 |\n";
        cout <<   "------------------------------------------------\n";
        cout << "10. Manage Rooms             (Prototype Pattern)\n";

        cout << "\n------------------------------------------------\n";
        cout <<   "|                   SYSTEM                     |\n";
        cout <<   "------------------------------------------------\n";
        cout << "11. View Command History     (Command Pattern)\n";
        cout << "12. Save Data                (Strategy Pattern)\n";
        cout << "0.  Exit\n";
        cout << "------------------------------------------------\n";

        int choice = InputHelper::getIntInRange("\nChoice: ", 0, 12);
        switch (choice) {
            case 1:  listAllDevices();        break;
            case 2:  addDevice();             break;
            case 3:  deleteDevice();          break;
            case 4:  editDevice();            break;
            case 5:  individualDeviceMenu();  break;
            case 6:  performActionOnAll();    break;
            case 7:  searchDevice();          break;
            case 8:  viewConnectionStatus();  break;
            case 9:  changeConnectionStatus();break;
            case 10: manageRooms();           break;
            case 11: viewCommandHistory();    break;
            case 12: saveToFile();            break;
            case 0:
                saveToFile();
                cout << "\nThank you for using Smart Campus System!\n";
                return;
        }
    }
}
