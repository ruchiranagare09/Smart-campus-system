#pragma once
#include <iostream>
#include <string>
#include <limits>
#include <sstream>

using namespace std;

// ─────────────────────────────────────────────
//  InputHelper  –  safe, crash-proof input utils
// ─────────────────────────────────────────────
namespace InputHelper {

    // Read an int; loops until valid integer is entered
    inline int getInt(const string& prompt = "") {
        int value;
        while (true) {
            if (!prompt.empty()) cout << prompt;
            if (cin >> value) {
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                return value;
            }
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "  [!] Invalid input. Please enter a whole number.\n";
        }
    }

    // Read an int clamped to [minVal, maxVal]
    inline int getIntInRange(const string& prompt, int minVal, int maxVal) {
        while (true) {
            int v = getInt(prompt);
            if (v >= minVal && v <= maxVal) return v;
            cout << "  [!] Please enter a number between " << minVal << " and " << maxVal << ".\n";
        }
    }

    // Read a double; loops until valid
    inline double getDouble(const string& prompt = "") {
        double value;
        while (true) {
            if (!prompt.empty()) cout << prompt;
            if (cin >> value) {
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                return value;
            }
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "  [!] Invalid input. Please enter a number.\n";
        }
    }

    // Read a non-empty trimmed line
    inline string getString(const string& prompt = "") {
        string line;
        while (true) {
            if (!prompt.empty()) cout << prompt;
            getline(cin, line);
            size_t start = line.find_first_not_of(" \t\r\n");
            if (start == string::npos) {
                cout << "  [!] Input cannot be empty.\n";
                continue;
            }
            size_t end = line.find_last_not_of(" \t\r\n");
            return line.substr(start, end - start + 1);
        }
    }

    // Read a single char from a set of allowed chars (case-insensitive)
    inline char getChar(const string& prompt, const string& allowed) {
        while (true) {
            if (!prompt.empty()) cout << prompt;
            string line;
            getline(cin, line);
            if (line.size() == 1) {
                char c = static_cast<char>(tolower(static_cast<unsigned char>(line[0])));
                if (allowed.find(c) != string::npos) return c;
            }
            cout << "  [!] Please enter one of: " << allowed << "\n";
        }
    }

    // Convert string to int safely
    inline bool tryParseInt(const string& s, int& out) {
        istringstream ss(s);
        return (ss >> out) && ss.eof();
    }

    // Convert string to double safely
    inline bool tryParseDouble(const string& s, double& out) {
        istringstream ss(s);
        return (ss >> out) && ss.eof();
    }

} // namespace InputHelper
