#include "DoorLock.h"
#include "InputHelper.h"
#include <iostream>

using namespace std;

DoorLock::DoorLock(int id, const string& name, const string& mfr,
                   bool lock, const string& lastUser)
    : Device(id, name, mfr), locked(lock), lastOpenedBy(lastUser) {}

void DoorLock::InteractionEvent() {
    if (!status) {
        cout << "  [!] Cannot control door lock. " << deviceName << " is inactive.\n";
        return;
    }
    cout << "\n--- Door Lock Status ---\n";
    cout << "Current Status  : " << (locked ? "Locked" : "Unlocked") << "\n";
    cout << "Last Opened By  : " << lastOpenedBy << "\n\n";
    cout << "1. Lock Door\n2. Unlock Door\n3. View Status Only\n";

    int choice = InputHelper::getIntInRange("Choice: ", 1, 3);

    if (choice == 1) {
        locked       = true;
        lastOpenedBy = InputHelper::getString("Enter your username: ");
        cout << "Door locked by " << lastOpenedBy << "\n";
        notifyObservers("Door locked by " + lastOpenedBy);
    } else if (choice == 2) {
        locked       = false;
        lastOpenedBy = InputHelper::getString("Enter your username: ");
        cout << "Door unlocked by " << lastOpenedBy << "\n";
        notifyObservers("Door unlocked by " + lastOpenedBy);
    }
}

void DoorLock::ViewInfo() const {
    Device::ViewInfo();
    cout << "Lock Status    : " << (locked ? "Locked" : "Unlocked") << "\n";
    cout << "Last Opened By : " << lastOpenedBy << "\n";
    cout << string(50, '=') << "\n";
}

string DoorLock::getType()      const { return "DoorLock"; }

string DoorLock::toFileString() const {
    return "DoorLock," + to_string(deviceID) + "," + deviceName + "," +
           manufacturer + "," + (locked ? "1" : "0") + "," + lastOpenedBy;
}

void DoorLock::editAttributes() {
    int lockChoice = InputHelper::getIntInRange("Lock/Unlock? (1=Lock, 0=Unlock): ", 0, 1);
    locked         = (lockChoice == 1);
    lastOpenedBy   = InputHelper::getString("Edit Last Opened By (current: " + lastOpenedBy + "): ");
    cout << "Attributes updated.\n";
    notifyObservers("Attributes edited");
}

shared_ptr<Device> DoorLock::clone(int newID) const {
    return make_shared<DoorLock>(newID, deviceName + "_copy", manufacturer, locked, lastOpenedBy);
}
