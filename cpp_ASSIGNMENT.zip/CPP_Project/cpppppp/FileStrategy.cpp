#include "FileStrategy.h"
#include "DeviceFactory.h"
#include "InputHelper.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

void TextFileStrategy::save(const string& filename,
                            const vector<shared_ptr<Device>>& /*devices*/,
                            const vector<Room>& rooms) {
    ofstream file(filename);
    if (!file.is_open()) {
        cout << "  [!] Error: Could not open file for saving.\n";
        return;
    }

    for (const auto& room : rooms) {
        file << "ROOM:" << room.getName() << "\n";
        for (const auto& device : room.getDevices()) {
            file << device->toFileString() << "\n";
        }
    }

    file.close();
    cout << "Data saved to " << filename << "\n";
}

void TextFileStrategy::load(const string& filename,
                            vector<shared_ptr<Device>>& devices,
                            vector<Room>& rooms) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "No existing data file found. Starting fresh.\n";
        return;
    }

    string line, currentRoom;

    while (getline(file, line)) {
        if (line.empty()) continue;

        if (line.substr(0, 5) == "ROOM:") {
            currentRoom = line.substr(5);
            rooms.push_back(Room(currentRoom));
            continue;
        }

        stringstream ss(line);
        string type, name, mfr;
        int    id = 0;

        getline(ss, type, ',');

        // Safe parse of id
        string idStr;
        getline(ss, idStr, ',');
        if (!InputHelper::tryParseInt(idStr, id)) continue;

        getline(ss, name, ',');
        getline(ss, mfr,  ',');

        vector<string> params;
        string param;
        while (getline(ss, param, ',')) {
            params.push_back(param);
        }

        shared_ptr<Device> device = DeviceFactory::createDevice(type, id, name, mfr, params);

        if (device) {
            devices.push_back(device);
            if (!currentRoom.empty() && !rooms.empty()) {
                rooms.back().addDevice(device);
            }
        }
    }

    file.close();
    cout << "Loaded " << devices.size() << " devices from file.\n";
}
