#include "DeviceObserver.h"
#include <iostream>

using namespace std;

void DeviceLogger::onDeviceStateChanged(const string& deviceName, const string& action) {
    cout << "[LOG] Device '" << deviceName << "' - " << action << "\n";
}
