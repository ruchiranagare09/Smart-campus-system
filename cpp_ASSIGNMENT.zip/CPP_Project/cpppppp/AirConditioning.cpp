#include "AirConditioning.h"
#include "InputHelper.h"
#include <iostream>

using namespace std;

AirConditioning::AirConditioning(int id, const string& name, const string& mfr, double temp)
    : Device(id, name, mfr), targetTemperature(temp) {}

void AirConditioning::InteractionEvent() {
    if (!status) {
        cout << "  [!] Cannot adjust temperature. " << deviceName << " is inactive.\n";
        return;
    }
    cout << "Current target temperature: " << targetTemperature << "C\n";
    targetTemperature = InputHelper::getDouble("Enter new target temperature: ");
    cout << "Target temperature set to " << targetTemperature << "C\n";
    notifyObservers("Temperature changed to " + to_string(targetTemperature) + "C");
}

void AirConditioning::ViewInfo() const {
    Device::ViewInfo();
    cout << "Target Temperature : " << targetTemperature << "C\n";
    cout << string(50, '=') << "\n";
}

string AirConditioning::getType()      const { return "AirConditioning"; }

string AirConditioning::toFileString() const {
    return "AirConditioning," + to_string(deviceID) + "," + deviceName + "," +
           manufacturer + "," + to_string(targetTemperature);
}

void AirConditioning::editAttributes() {
    targetTemperature = InputHelper::getDouble("Edit Target Temperature (current: "
                        + to_string(targetTemperature) + " C): ");
    cout << "Target temperature updated.\n";
    notifyObservers("Attributes edited");
}

shared_ptr<Device> AirConditioning::clone(int newID) const {
    return make_shared<AirConditioning>(newID, deviceName + "_copy", manufacturer, targetTemperature);
}
