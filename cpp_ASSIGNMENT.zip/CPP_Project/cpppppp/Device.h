#pragma once
#include <string>
#include <vector>
#include <memory>
#include "DeviceObserver.h"

using namespace std;

// ─────────────────────────────────────────────
//  Abstract base class for all campus devices
// ─────────────────────────────────────────────

class Device {
protected:
    int    deviceID;
    string deviceName;
    string manufacturer;
    bool   status;
    bool   connectionStatus;

    vector<shared_ptr<DeviceObserver>> observers;

public:
    Device(int id, const string& name, const string& mfr);
    virtual ~Device() = default;

    // Observer helpers
    void attachObserver(shared_ptr<DeviceObserver> observer);
    void notifyObservers(const string& action);

    // Getters
    int    getID()               const;
    string getName()             const;
    string getManufacturer()     const;
    bool   getStatus()           const;
    bool   getConnectionStatus() const;

    // Setters
    void setName(const string& name);
    void setManufacturer(const string& mfr);
    void setConnectionStatus(bool conn);

    // Common operations
    virtual void Activate();
    virtual void Deactivate();
    bool CheckConnection() const;
    virtual void ViewInfo() const;

    // Pure virtual interface
    virtual void   InteractionEvent()           = 0;
    virtual string getType()              const = 0;
    virtual string toFileString()         const = 0;
    virtual void   editAttributes()             = 0;
    virtual shared_ptr<Device> clone(int newID) const = 0;
};
