#pragma once
#include "Device.h"

using namespace std;

// ─────────────────────────────────────────────
//  SecurityCamera device
// ─────────────────────────────────────────────

class SecurityCamera : public Device {
private:
    string cameraQuality;
    string power;

public:
    SecurityCamera(int id, const string& name, const string& mfr,
                   const string& quality, const string& pwr);

    void   InteractionEvent()           override;
    void   ViewInfo()             const override;
    string getType()              const override;
    string toFileString()         const override;
    void   editAttributes()             override;
    shared_ptr<Device> clone(int newID) const override;
};
