#pragma once
#include "Device.h"

using namespace std;

// ─────────────────────────────────────────────
//  DoorLock device
// ─────────────────────────────────────────────

class DoorLock : public Device {
private:
    bool   locked;
    string lastOpenedBy;

public:
    DoorLock(int id, const string& name, const string& mfr,
             bool lock, const string& lastUser);

    void   InteractionEvent()           override;
    void   ViewInfo()             const override;
    string getType()              const override;
    string toFileString()         const override;
    void   editAttributes()             override;
    shared_ptr<Device> clone(int newID) const override;
};
