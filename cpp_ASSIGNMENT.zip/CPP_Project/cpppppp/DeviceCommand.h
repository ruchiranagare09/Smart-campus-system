#pragma once
#include "Device.h"
#include <vector>
#include <memory>

using namespace std;

// ─────────────────────────────────────────────
//  DeviceCommand  –  Command Pattern (base)
// ─────────────────────────────────────────────

class DeviceCommand {
public:
    virtual ~DeviceCommand() = default;
    virtual void   execute()              = 0;
    virtual string getDescription() const = 0;
};

// ─── ActivateCommand ─────────────────────────
class ActivateCommand : public DeviceCommand {
    shared_ptr<Device> device;
public:
    explicit ActivateCommand(shared_ptr<Device> dev);
    void   execute()              override;
    string getDescription() const override;
};

// ─── DeactivateCommand ───────────────────────
class DeactivateCommand : public DeviceCommand {
    shared_ptr<Device> device;
public:
    explicit DeactivateCommand(shared_ptr<Device> dev);
    void   execute()              override;
    string getDescription() const override;
};

// ─── InteractCommand ─────────────────────────
class InteractCommand : public DeviceCommand {
    shared_ptr<Device> device;
public:
    explicit InteractCommand(shared_ptr<Device> dev);
    void   execute()              override;
    string getDescription() const override;
};

// ─────────────────────────────────────────────
//  CommandInvoker  –  stores and runs commands
// ─────────────────────────────────────────────
class CommandInvoker {
    vector<shared_ptr<DeviceCommand>> commandHistory;
public:
    void executeCommand(shared_ptr<DeviceCommand> command);
    void showHistory() const;
};
