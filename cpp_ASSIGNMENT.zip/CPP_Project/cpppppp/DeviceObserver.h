#pragma once
#include <string>

using namespace std;

// ─────────────────────────────────────────────
//  Observer interface + DeviceLogger
// ─────────────────────────────────────────────

class DeviceObserver {
public:
    virtual ~DeviceObserver() = default;
    virtual void onDeviceStateChanged(const string& deviceName, const string& action) = 0;
};

class DeviceLogger : public DeviceObserver {
public:
    void onDeviceStateChanged(const string& deviceName, const string& action) override;
};
