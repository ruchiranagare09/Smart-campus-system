#pragma once
#include "Device.h"
#include <vector>
#include <memory>

using namespace std;

// ─────────────────────────────────────────────
//  Room  –  groups devices together
// ─────────────────────────────────────────────

class Room {
private:
    string                      roomName;
    vector<shared_ptr<Device>>  devices;

public:
    explicit Room(const string& name);

    string getName() const;
    void   setName(const string& name);

    void addDevice(shared_ptr<Device> device);
    bool removeDevice(int deviceID);

    vector<shared_ptr<Device>>&       getDevices();
    const vector<shared_ptr<Device>>& getDevices() const;

    void activateAll();
    void deactivateAll();
    void listDevices() const;
};
