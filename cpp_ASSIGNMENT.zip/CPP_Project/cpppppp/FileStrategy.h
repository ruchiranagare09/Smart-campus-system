#pragma once
#include "Device.h"
#include "Room.h"
#include <string>
#include <vector>
#include <memory>

using namespace std;

// ─────────────────────────────────────────────
//  FileStrategy  –  Strategy Pattern (base)
// ─────────────────────────────────────────────

class FileStrategy {
public:
    virtual ~FileStrategy() = default;
    virtual void save(const string& filename,
                      const vector<shared_ptr<Device>>& devices,
                      const vector<Room>& rooms) = 0;
    virtual void load(const string& filename,
                      vector<shared_ptr<Device>>& devices,
                      vector<Room>& rooms) = 0;
};

// ─────────────────────────────────────────────
//  TextFileStrategy  –  concrete strategy
// ─────────────────────────────────────────────

class TextFileStrategy : public FileStrategy {
public:
    void save(const string& filename,
              const vector<shared_ptr<Device>>& devices,
              const vector<Room>& rooms) override;

    void load(const string& filename,
              vector<shared_ptr<Device>>& devices,
              vector<Room>& rooms) override;
};
