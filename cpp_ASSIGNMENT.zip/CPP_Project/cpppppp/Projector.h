#pragma once
#include "Device.h"

using namespace std;

// ─────────────────────────────────────────────
//  Projector device
// ─────────────────────────────────────────────

class Projector : public Device {
private:
    string input;
    int    brightnessLevel;

public:
    Projector(int id, const string& name, const string& mfr,
              const string& inp, int brightness);

    void   InteractionEvent()           override;
    void   ViewInfo()             const override;
    string getType()              const override;
    string toFileString()         const override;
    void   editAttributes()             override;
    shared_ptr<Device> clone(int newID) const override;
};
