#pragma once
#include "Device.h"
#include <vector>
#include <memory>

using namespace std;

// ─────────────────────────────────────────────
//  DeviceFactory  –  Factory Pattern
// ─────────────────────────────────────────────

class DeviceFactory {
public:
    static shared_ptr<Device> createDevice(const string& type,
                                           int id,
                                           const string& name,
                                           const string& mfr,
                                           const vector<string>& params);
};
