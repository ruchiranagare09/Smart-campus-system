#pragma once
#include "Device.h"

using namespace std;

// ─────────────────────────────────────────────
//  AirConditioning device
// ─────────────────────────────────────────────

class AirConditioning : public Device {
private:
    double targetTemperature;

public:
    AirConditioning(int id, const string& name, const string& mfr, double temp);

    void   InteractionEvent()           override;
    void   ViewInfo()             const override;
    string getType()              const override;
    string toFileString()         const override;
    void   editAttributes()             override;
    shared_ptr<Device> clone(int newID) const override;
};
