#include "SecurityCamera.h"
#include "InputHelper.h"
#include <iostream>

using namespace std;

SecurityCamera::SecurityCamera(int id, const string& name, const string& mfr,
                               const string& quality, const string& pwr)
    : Device(id, name, mfr), cameraQuality(quality), power(pwr) {}

void SecurityCamera::InteractionEvent() {
    if (!status) {
        cout << "  [!] Cannot view camera. " << deviceName << " is inactive.\n";
        return;
    }
    cout << "Now viewing camera: " << deviceName << "\n";
    cout << "   Quality: " << cameraQuality << "\n";
    notifyObservers("Camera viewed");
}

void SecurityCamera::ViewInfo() const {
    Device::ViewInfo();
    cout << "Camera Quality : " << cameraQuality << "\n";
    cout << "Power Source   : " << power << "\n";
    cout << string(50, '=') << "\n";
}

string SecurityCamera::getType()      const { return "SecurityCamera"; }

string SecurityCamera::toFileString() const {
    return "SecurityCamera," + to_string(deviceID) + "," + deviceName + "," +
           manufacturer + "," + cameraQuality + "," + power;
}

void SecurityCamera::editAttributes() {
    cameraQuality = InputHelper::getString("Edit Camera Quality (current: " + cameraQuality + "): ");
    power         = InputHelper::getString("Edit Power Source  (current: " + power + "): ");
    cout << "Attributes updated.\n";
    notifyObservers("Attributes edited");
}

shared_ptr<Device> SecurityCamera::clone(int newID) const {
    return make_shared<SecurityCamera>(newID, deviceName + "_copy", manufacturer, cameraQuality, power);
}
