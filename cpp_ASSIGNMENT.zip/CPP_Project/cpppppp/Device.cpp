#include "Device.h"
#include <iostream>

using namespace std;

Device::Device(int id, const string& name, const string& mfr)
    : deviceID(id), deviceName(name), manufacturer(mfr),
      status(false), connectionStatus(true) {}

void Device::attachObserver(shared_ptr<DeviceObserver> observer) {
    observers.push_back(observer);
}

void Device::notifyObservers(const string& action) {
    for (auto& obs : observers)
        obs->onDeviceStateChanged(deviceName, action);
}

int    Device::getID()               const { return deviceID; }
string Device::getName()             const { return deviceName; }
string Device::getManufacturer()     const { return manufacturer; }
bool   Device::getStatus()           const { return status; }
bool   Device::getConnectionStatus() const { return connectionStatus; }

void Device::setName(const string& name)      { deviceName   = name; }
void Device::setManufacturer(const string& m) { manufacturer = m; }

void Device::setConnectionStatus(bool conn) {
    connectionStatus = conn;
    notifyObservers(conn ? "Connected" : "Disconnected");
}

void Device::Activate() {
    status = true;
    cout << deviceName << " has been activated.\n";
    notifyObservers("Activated");
}

void Device::Deactivate() {
    status = false;
    cout << deviceName << " has been deactivated.\n";
    notifyObservers("Deactivated");
}

bool Device::CheckConnection() const { return connectionStatus; }

void Device::ViewInfo() const {
    cout << "\n" << string(50, '=') << "\n";
    cout << "Device ID    : " << deviceID    << "\n";
    cout << "Device Name  : " << deviceName  << "\n";
    cout << "Manufacturer : " << manufacturer << "\n";
    cout << "Type         : " << getType()    << "\n";
    cout << "Status       : " << (status           ? "Active"     : "Inactive")     << "\n";
    cout << "Connection   : " << (connectionStatus ? "Connected"  : "Disconnected") << "\n";
}
