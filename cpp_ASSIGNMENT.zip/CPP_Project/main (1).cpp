/*
 * ═══════════════════════════════════════════════════════════════════════════
 * |                    SMART CAMPUS MANAGEMENT SYSTEM                       |
 * ═══════════════════════════════════════════════════════════════════════════
 */


// library i used.....
#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <unordered_map>
#include <functional>

using namespace std;

//C++11 compatibility.....
#if __cplusplus < 201402L
namespace std {
    template<typename T, typename... Args>
    unique_ptr<T> make_unique(Args&&... args) {
        return unique_ptr<T>(new T(std::forward<Args>(args)...));
    }
}
#endif

//my_classes.......
class Device;
class DeviceObserver;

//Class_1: DeviceObserver

class DeviceObserver {
public:
    virtual ~DeviceObserver() = default;
    virtual void onDeviceStateChanged(const string& deviceName, const string& action) = 0;
};

//Class_2: DeviceLogger

class DeviceLogger : public DeviceObserver {
public:
    void onDeviceStateChanged(const string& deviceName, const string& action) override {
        cout << "[LOG] Device '" << deviceName << "' - " << action << endl;
    }
};

//Class_3: Device

class Device {
protected:
    int deviceID;
    string deviceName;
    string manufacturer;
    bool status;
    bool connectionStatus;
    
    vector<shared_ptr<DeviceObserver>> observers;

public:
    Device(int id, const string& name, const string& mfr) 
        : deviceID(id), deviceName(name), manufacturer(mfr), 
          status(false), connectionStatus(true) {}
    
    virtual ~Device() = default;
    
    void attachObserver(shared_ptr<DeviceObserver> observer) {
        observers.push_back(observer);
    }
    
    void notifyObservers(const string& action) {
        for (auto& observer : observers) {
            observer->onDeviceStateChanged(deviceName, action);
        }
    }
    
    // all Getters.......
    int getID() const { return deviceID; }
    string getName() const { return deviceName; }
    string getManufacturer() const { return manufacturer; }
    bool getStatus() const { return status; }
    bool getConnectionStatus() const { return connectionStatus; }
    
    // all Setters.....
    void setName(const string& name) { deviceName = name; }
    void setManufacturer(const string& mfr) { manufacturer = mfr; }
    void setConnectionStatus(bool conn) { 
        connectionStatus = conn; 
        notifyObservers(conn ? "Connected" : "Disconnected");
    }
    
    virtual void Activate() {
        status = true;
        cout << "" << deviceName << " has been activated.\n";
        notifyObservers("Activated");
    }
    
    virtual void Deactivate() {
        status = false;
        cout << "" << deviceName << " has been deactivated.\n";
        notifyObservers("Deactivated");
    }
    
    bool CheckConnection() const {
        return connectionStatus;
    }
    
    virtual void ViewInfo() const {
        cout << "\n" << string(50, '=') << "\n";
        cout << "Device ID: " << deviceID << "\n";
        cout << "Device Name: " << deviceName << "\n";
        cout << "Manufacturer: " << manufacturer << "\n";
        cout << "Type: " << getType() << "\n";
        cout << "Status: " << (status ? "Active" : "Inactive") << "\n";
        cout << "Connection: " << (connectionStatus ? "Connected" : "Disconnected") << "\n";
    }
    
    virtual void InteractionEvent() = 0;
    virtual string getType() const = 0;
    virtual string toFileString() const = 0;
    virtual void editAttributes() = 0;
    virtual shared_ptr<Device> clone(int newID) const = 0;  // Prototype pattern for duplication
};

//Class_4: SecurityCamera

class SecurityCamera : public Device {
private:
    string cameraQuality;
    string power;

public:
    SecurityCamera(int id, const string& name, const string& mfr, 
                   const string& quality, const string& pwr)
        : Device(id, name, mfr), cameraQuality(quality), power(pwr) {}
    
    void InteractionEvent() override {
        if (!status) {
            cout << "✗ Cannot view camera. " << deviceName << " is inactive.\n";
            return;
        }
        cout << "📹 Now viewing camera: " << deviceName << "\n";
        cout << "   Quality: " << cameraQuality << "\n";
        notifyObservers("Camera viewed");
    }
    
    void ViewInfo() const override {
        Device::ViewInfo();
        cout << "Camera Quality: " << cameraQuality << "\n";
        cout << "Power Source: " << power << "\n";
        cout << string(50, '=') << "\n";
    }
    
    string getType() const override { return "SecurityCamera"; }
    
    string toFileString() const override {
        return "SecurityCamera," + to_string(deviceID) + "," + deviceName + "," + 
               manufacturer + "," + cameraQuality + "," + power;
    }
    
    void editAttributes() override {
        cout << "Edit Camera Quality (current: " << cameraQuality << "): ";
        cin.ignore();
        getline(cin, cameraQuality);
        cout << "Edit Power Source (current: " << power << "): ";
        getline(cin, power);
        cout << "✓ Attributes updated.\n";
        notifyObservers("Attributes edited");
    }
    
//clone method
    shared_ptr<Device> clone(int newID) const override {
        return make_shared<SecurityCamera>(newID, deviceName + "_copy", 
                                          manufacturer, cameraQuality, power);
    }
};

//Class_5: AirConditioning

class AirConditioning : public Device {
private:
    double targetTemperature;

public:
    AirConditioning(int id, const string& name, const string& mfr, double temp)
        : Device(id, name, mfr), targetTemperature(temp) {}
    
    void InteractionEvent() override {
        if (!status) {
            cout << "✗ Cannot adjust temperature. " << deviceName << " is inactive.\n";
            return;
        }
        cout << "Current target temperature: " << targetTemperature << "°C\n";
        cout << "Enter new target temperature: ";
        cin >> targetTemperature;
        cout << "✓ Target temperature set to " << targetTemperature << "°C\n";
        notifyObservers("Temperature changed to " + to_string(targetTemperature) + "°C");
    }
    
    void ViewInfo() const override {
        Device::ViewInfo();
        cout << "Target Temperature: " << targetTemperature << "°C\n";
        cout << string(50, '=') << "\n";
    }
    
    string getType() const override { return "AirConditioning"; }
    
    string toFileString() const override {
        return "AirConditioning," + to_string(deviceID) + "," + deviceName + "," + 
               manufacturer + "," + to_string(targetTemperature);
    }
    
    void editAttributes() override {
        cout << "Edit Target Temperature (current: " << targetTemperature << "°C): ";
        cin >> targetTemperature;
        cout << "✓ Target temperature updated.\n";
        notifyObservers("Attributes edited");
    }
    
    shared_ptr<Device> clone(int newID) const override {
        return make_shared<AirConditioning>(newID, deviceName + "_copy", 
                                           manufacturer, targetTemperature);
    }
};

//Class-6: Projector

class Projector : public Device {
private:
    string input;
    int brightnessLevel;

public:
    Projector(int id, const string& name, const string& mfr, 
              const string& inp, int brightness)
        : Device(id, name, mfr), input(inp), brightnessLevel(brightness) {}
    
    void InteractionEvent() override {
        if (!status) {
            cout << "✗ Cannot adjust projector. " << deviceName << " is inactive.\n";
            return;
        }
        cout << "\n--- Projector Settings ---\n";
        cout << "1. Change Input Source (current: " << input << ")\n";
        cout << "2. Change Brightness (current: " << brightnessLevel << ")\n";
        cout << "3. Both\n";
        cout << "Choice: ";
        int choice;
        cin >> choice;
        
        if (choice == 1 || choice == 3) {
            cout << "Enter input source (VGA/HDMI/Wireless): ";
            cin.ignore();
            getline(cin, input);
        }
        if (choice == 2 || choice == 3) {
            cout << "Enter brightness level (0-100): ";
            cin >> brightnessLevel;
            brightnessLevel = max(0, min(100, brightnessLevel));
        }
        cout << " Projector settings updated.\n";
        notifyObservers("Projector settings changed");
    }
    
    void ViewInfo() const override {
        Device::ViewInfo();
        cout << "Input Source: " << input << "\n";
        cout << "Brightness Level: " << brightnessLevel << "\n";
        cout << string(50, '=') << "\n";
    }
    
    string getType() const override { return "Projector"; }
    
    string toFileString() const override {
        return "Projector," + to_string(deviceID) + "," + deviceName + "," + 
               manufacturer + "," + input + "," + to_string(brightnessLevel);
    }
    
    void editAttributes() override {
        cout << "Edit Input Source (current: " << input << "): ";
        cin.ignore();
        getline(cin, input);
        cout << "Edit Brightness Level (current: " << brightnessLevel << "): ";
        cin >> brightnessLevel;
        brightnessLevel = max(0, min(100, brightnessLevel));
        cout << "✓ Attributes updated.\n";
        notifyObservers("Attributes edited");
    }
    
    shared_ptr<Device> clone(int newID) const override {
        return make_shared<Projector>(newID, deviceName + "_copy", 
                                     manufacturer, input, brightnessLevel);
    }
};

//Class_7: RoomLighting

class RoomLighting : public Device {
private:
    int brightnessLevel;

public:
    RoomLighting(int id, const string& name, const string& mfr, int brightness)
        : Device(id, name, mfr), brightnessLevel(brightness) {}
    
    void InteractionEvent() override {
        if (!status) {
            cout << " Cannot adjust lighting. " << deviceName << " is inactive.\n";
            return;
        }
        cout << "Current brightness level: " << brightnessLevel << "\n";
        cout << "Enter new brightness level (0-100): ";
        cin >> brightnessLevel;
        brightnessLevel = max(0, min(100, brightnessLevel));
        cout << " Brightness set to " << brightnessLevel << "\n";
        notifyObservers("Brightness changed to " + to_string(brightnessLevel));
    }
    
    void ViewInfo() const override {
        Device::ViewInfo();
        cout << "Brightness Level: " << brightnessLevel << "\n";
        cout << string(50, '=') << "\n";
    }
    
    string getType() const override { return "RoomLighting"; }
    
    string toFileString() const override {
        return "RoomLighting," + to_string(deviceID) + "," + deviceName + "," + 
               manufacturer + "," + to_string(brightnessLevel);
    }
    
    void editAttributes() override {
        cout << "Edit Brightness Level (current: " << brightnessLevel << "): ";
        cin >> brightnessLevel;
        brightnessLevel = max(0, min(100, brightnessLevel));
        cout << "✓ Brightness level updated.\n";
        notifyObservers("Attributes edited");
    }
    
    shared_ptr<Device> clone(int newID) const override {
        return make_shared<RoomLighting>(newID, deviceName + "_copy", 
                                        manufacturer, brightnessLevel);
    }
};

//Class_8: DoorLock

class DoorLock : public Device {
private:
    bool locked;
    string lastOpenedBy;

public:
    DoorLock(int id, const string& name, const string& mfr, 
             bool lock, const string& lastUser)
        : Device(id, name, mfr), locked(lock), lastOpenedBy(lastUser) {}
    
    void InteractionEvent() override {
        if (!status) {
            cout << "✗ Cannot control door lock. " << deviceName << " is inactive.\n";
            return;
        }
        cout << "\n--- Door Lock Status ---\n";
        cout << "Current Status: " << (locked ? "🔒 Locked" : "🔓 Unlocked") << "\n";
        cout << "Last Opened By: " << lastOpenedBy << "\n\n";
        cout << "1. Lock Door\n2. Unlock Door\n3. View Status Only\n";
        cout << "Choice: ";
        int choice;
        cin >> choice;
        
        if (choice == 1) {
            locked = true;
            cout << "Enter your username: ";
            cin.ignore();
            getline(cin, lastOpenedBy);
            cout << "✓ Door locked by " << lastOpenedBy << "\n";
            notifyObservers("Door locked by " + lastOpenedBy);
        } else if (choice == 2) {
            locked = false;
            cout << "Enter your username: ";
            cin.ignore();
            getline(cin, lastOpenedBy);
            cout << "✓ Door unlocked by " << lastOpenedBy << "\n";
            notifyObservers("Door unlocked by " + lastOpenedBy);
        }
    }
    
    void ViewInfo() const override {
        Device::ViewInfo();
        cout << "Lock Status: " << (locked ? "Locked" : "Unlocked") << "\n";
        cout << "Last Opened By: " << lastOpenedBy << "\n";
        cout << string(50, '=') << "\n";
    }
    
    string getType() const override { return "DoorLock"; }
    
    string toFileString() const override {
        return "DoorLock," + to_string(deviceID) + "," + deviceName + "," + 
               manufacturer + "," + (locked ? "1" : "0") + "," + lastOpenedBy;
    }
    
    void editAttributes() override {
        cout << "Lock/Unlock? (1=Lock, 0=Unlock): ";
        int lockChoice;
        cin >> lockChoice;
        locked = (lockChoice == 1);
        cout << "Edit Last Opened By (current: " << lastOpenedBy << "): ";
        cin.ignore();
        getline(cin, lastOpenedBy);
        cout << "✓ Attributes updated.\n";
        notifyObservers("Attributes edited");
    }
    
    shared_ptr<Device> clone(int newID) const override {
        return make_shared<DoorLock>(newID, deviceName + "_copy", 
                                    manufacturer, locked, lastOpenedBy);
    }
};

//Class_9: DeviceFactory

class DeviceFactory {
public:

    static shared_ptr<Device> createDevice(const string& type, int id, 
                                          const string& name, const string& mfr,
                                          const vector<string>& params) {
        if (type == "SecurityCamera") {
            return make_shared<SecurityCamera>(id, name, mfr, 
                                              params.size() > 0 ? params[0] : "1080p",
                                              params.size() > 1 ? params[1] : "mains powered");
        }
        else if (type == "AirConditioning") {
            double temp = params.size() > 0 ? stod(params[0]) : 22.0;
            return make_shared<AirConditioning>(id, name, mfr, temp);
        }
        else if (type == "Projector") {
            string input = params.size() > 0 ? params[0] : "HDMI";
            int brightness = params.size() > 1 ? stoi(params[1]) : 50;
            return make_shared<Projector>(id, name, mfr, input, brightness);
        }
        else if (type == "RoomLighting") {
            int brightness = params.size() > 0 ? stoi(params[0]) : 50;
            return make_shared<RoomLighting>(id, name, mfr, brightness);
        }
        else if (type == "DoorLock") {
            bool locked = params.size() > 0 ? (params[0] == "1") : false;
            string lastUser = params.size() > 1 ? params[1] : "System";
            return make_shared<DoorLock>(id, name, mfr, locked, lastUser);
        }
        return nullptr;
    }
};

//Class-10: DeviceCommand

class DeviceCommand {
public:
    virtual ~DeviceCommand() = default;
    virtual void execute() = 0;
    virtual string getDescription() const = 0;
};

//Class-10: ActivateCommand

class ActivateCommand : public DeviceCommand {
private:
    shared_ptr<Device> device;
public:
    explicit ActivateCommand(shared_ptr<Device> dev) : device(dev) {}
    void execute() override { device->Activate(); }
    string getDescription() const override { 
        return "Activate " + device->getName(); 
    }
};

//Class-11: DeactivateCommand

class DeactivateCommand : public DeviceCommand {
private:
    shared_ptr<Device> device;
public:
    explicit DeactivateCommand(shared_ptr<Device> dev) : device(dev) {}
    void execute() override { device->Deactivate(); }
    string getDescription() const override { 
        return "Deactivate " + device->getName(); 
    }
};

//Class-12: InteractCommand

class InteractCommand : public DeviceCommand {
private:
    shared_ptr<Device> device;
public:
    explicit InteractCommand(shared_ptr<Device> dev) : device(dev) {}
    void execute() override { device->InteractionEvent(); }
    string getDescription() const override { 
        return "Interact with " + device->getName(); 
    }
};

//Class-13: CommandInvoker

class CommandInvoker {
private:
    vector<shared_ptr<DeviceCommand>> commandHistory;
public:
    void executeCommand(shared_ptr<DeviceCommand> command) {
        command->execute();
        commandHistory.push_back(command);
    }
    
    void showHistory() const {
        cout << "\n--- Command History ---\n";
        for (size_t i = 0; i < commandHistory.size(); i++) {
            cout << i + 1 << ". " << commandHistory[i]->getDescription() << "\n";
        }
    }
};

//Class-14: FileStrategy

class FileStrategy {
public:
    virtual ~FileStrategy() = default;
    virtual void save(const string& filename, 
                     const vector<shared_ptr<Device>>& devices,
                     const vector<class Room>& rooms) = 0;
    virtual void load(const string& filename, 
                     vector<shared_ptr<Device>>& devices,
                     vector<class Room>& rooms) = 0;
};

//Class-15: Room

class Room {
private:
    string roomName;
    vector<shared_ptr<Device>> devices;

public:
    Room(const string& name) : roomName(name) {}
    
    string getName() const { return roomName; }
    void setName(const string& name) { roomName = name; }
    
    void addDevice(shared_ptr<Device> device) {
        devices.push_back(device);
    }
    
    bool removeDevice(int deviceID) {
        auto it = remove_if(devices.begin(), devices.end(),
            [deviceID](const shared_ptr<Device>& d) { return d->getID() == deviceID; });
        
        if (it != devices.end()) {
            devices.erase(it, devices.end());
            return true;
        }
        return false;
    }
    
    vector<shared_ptr<Device>>& getDevices() { return devices; }
    const vector<shared_ptr<Device>>& getDevices() const { return devices; }
    
    void activateAll() {
        cout << "\nActivating all devices in " << roomName << "...\n";
        for (auto& device : devices) {
            device->Activate();
        }
    }
    
    void deactivateAll() {
        cout << "\nDeactivating all devices in " << roomName << "...\n";
        for (auto& device : devices) {
            device->Deactivate();
        }
    }
    
    void listDevices() const {
        if (devices.empty()) {
            cout << "No devices in this room.\n";
            return;
        }
        cout << "\n--- Devices in " << roomName << " ---\n";
        for (size_t i = 0; i < devices.size(); i++) {
            cout << i + 1 << ". ID:" << devices[i]->getID() 
                 << " - " << devices[i]->getName() 
                 << " (" << devices[i]->getType() << ") - "
                 << (devices[i]->getStatus() ? "Active" : "Inactive") << "\n";
        }
    }
};

//Class-16: TextFileStrategy

class TextFileStrategy : public FileStrategy {
public:
    void save(const string& filename, 
             const vector<shared_ptr<Device>>& devices,
             const vector<Room>& rooms) override {
        ofstream file(filename);
        if (!file.is_open()) {
            cout << "Error saving data.\n";
            return;
        }
        
        for (const auto& room : rooms) {
            file << "ROOM:" << room.getName() << "\n";
            for (const auto& device : room.getDevices()) {
                file << device->toFileString() << "\n";
            }
        }
        
        file.close();
        cout << "✓ Data saved to " << filename << "\n";
    }
    
    void load(const string& filename, 
             vector<shared_ptr<Device>>& devices,
             vector<Room>& rooms) override {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "No existing data file found. Starting fresh.\n";
            return;
        }
        
        string line, currentRoom;
        
        while (getline(file, line)) {
            if (line.empty()) continue;
            
            if (line.substr(0, 5) == "ROOM:") {
                currentRoom = line.substr(5);
                rooms.push_back(Room(currentRoom));
                continue;
            }
            
            stringstream ss(line);
            string type;
            int id;
            string name, mfr;
            
            getline(ss, type, ',');
            ss >> id;
            ss.ignore();
            getline(ss, name, ',');
            getline(ss, mfr, ',');
            
            vector<string> params;
            string param;
            while (getline(ss, param, ',')) {
                params.push_back(param);
            }
            
            // Use Factory Pattern to create device
            shared_ptr<Device> device = DeviceFactory::createDevice(type, id, name, mfr, params);
            
            if (device) {
                devices.push_back(device);
                if (!currentRoom.empty() && !rooms.empty()) {
                    rooms.back().addDevice(device);
                }
            }
        }
        
        file.close();
        cout << "✓ Loaded " << devices.size() << " devices from file.\n";
    }
};

//Class-17: SmartCampusSystem

class SmartCampusSystem {
private:
    vector<shared_ptr<Device>> allDevices;
    vector<Room> rooms;
    shared_ptr<DeviceObserver> logger;
    unique_ptr<FileStrategy> fileStrategy;
    CommandInvoker commandInvoker;
    
    //constructor.......
    SmartCampusSystem() {
        logger = make_shared<DeviceLogger>();
        fileStrategy = make_unique<TextFileStrategy>();
        loadFromFile();
    }
    
    SmartCampusSystem(const SmartCampusSystem&) = delete;
    SmartCampusSystem& operator=(const SmartCampusSystem&) = delete;
    
    int getNextID() const {
        int maxID = 0;
        for (const auto& device : allDevices) {
            if (device->getID() > maxID) {
                maxID = device->getID();
            }
        }
        return maxID + 1;
    }
    
    bool isIDDuplicate(int id) const {
        return any_of(allDevices.begin(), allDevices.end(),
            [id](const shared_ptr<Device>& d) { return d->getID() == id; });
    }
    
    shared_ptr<Device> findDeviceByID(int id) {
        auto it = find_if(allDevices.begin(), allDevices.end(),
            [id](const shared_ptr<Device>& d) { return d->getID() == id; });
        return (it != allDevices.end()) ? *it : nullptr;
    }
    
    Room* findRoomByName(const string& name) {
        auto it = find_if(rooms.begin(), rooms.end(),
            [&name](const Room& r) { return r.getName() == name; });
        return (it != rooms.end()) ? &(*it) : nullptr;
    }

public:
    //getter.....
    static SmartCampusSystem& getInstance() {
        static SmartCampusSystem instance;
        return instance;
    }
    
    //deconstructor......
    ~SmartCampusSystem() {
        saveToFile();
    }
    
    void loadFromFile() {
        fileStrategy->load("campus_data.txt", allDevices, rooms);
        
        for (auto& device : allDevices) {
            device->attachObserver(logger);
        }
    }
    
    void saveToFile() {
        fileStrategy->save("campus_data.txt", allDevices, rooms);
    }
    
    void addDevice() {
        cout << "\n--- Add New Device ---\n";
        cout << "1. Security Camera\n2. Air Conditioning\n3. Projector\n";
        cout << "4. Room Lighting\n5. Door Lock\n";
        cout << "Choice: ";
        int choice;
        cin >> choice;
        
        int id;
        cout << "Enter Device ID: ";
        cin >> id;
        
        if (isIDDuplicate(id)) {
            cout << "Error: Device ID " << id << " already exists!\n";
            return;
        }
        
        string name, mfr;
        cout << "Enter Device Name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter Manufacturer: ";
        getline(cin, mfr);
        
        vector<string> params;
        shared_ptr<Device> device;
        
        switch(choice) {
            case 1: {
                string quality, power;
                cout << "Enter Camera Quality: ";
                getline(cin, quality);
                cout << "Enter Power Source: ";
                getline(cin, power);
                params = {quality, power};
                device = DeviceFactory::createDevice("SecurityCamera", id, name, mfr, params);
                break;
            }
            case 2: {
                string temp;
                cout << "Enter Target Temperature: ";
                getline(cin, temp);
                params = {temp};
                device = DeviceFactory::createDevice("AirConditioning", id, name, mfr, params);
                break;
            }
            case 3: {
                string input, brightness;
                cout << "Enter Input Source: ";
                getline(cin, input);
                cout << "Enter Brightness (0-100): ";
                getline(cin, brightness);
                params = {input, brightness};
                device = DeviceFactory::createDevice("Projector", id, name, mfr, params);
                break;
            }
            case 4: {
                string brightness;
                cout << "Enter Brightness (0-100): ";
                getline(cin, brightness);
                params = {brightness};
                device = DeviceFactory::createDevice("RoomLighting", id, name, mfr, params);
                break;
            }
            case 5: {
                string locked, lastUser;
                cout << "Locked? (1=Yes, 0=No): ";
                getline(cin, locked);
                cout << "Last Opened By: ";
                getline(cin, lastUser);
                params = {locked, lastUser};
                device = DeviceFactory::createDevice("DoorLock", id, name, mfr, params);
                break;
            }
            default:
                cout << "Invalid choice.\n";
                return;
        }
        
        if (device) {
            device->attachObserver(logger);
            allDevices.push_back(device);
            
            cout << "\nAdd to room? (y/n): ";
            char addToRoom;
            cin >> addToRoom;
            if (addToRoom == 'y' || addToRoom == 'Y') {
                addDeviceToRoom(device);
            }
            
            cout << "Device added successfully!\n";
        }
    }
    
    void deleteDevice() {
        if (allDevices.empty()) {
            cout << "No devices to delete.\n";
            return;
        }
        
        cout << "Enter Device ID to delete: ";
        int id;
        cin >> id;
        
        auto it = remove_if(allDevices.begin(), allDevices.end(),
            [id](const shared_ptr<Device>& d) { return d->getID() == id; });
        
        if (it != allDevices.end()) {
            for (auto& room : rooms) {
                room.removeDevice(id);
            }
            allDevices.erase(it, allDevices.end());
            cout << "Device deleted successfully.\n";
        } else {
            cout << "Device not found.\n";
        }
    }
    
    void editDevice() {
        if (allDevices.empty()) {
            cout << "No devices available.\n";
            return;
        }
        
        cout << "Enter Device ID to edit: ";
        int id;
        cin >> id;
        
        auto device = findDeviceByID(id);
        if (device) {
            cout << "\nEditing " << device->getName() << ":\n";
            cout << "1. Edit Name\n2. Edit Manufacturer\n";
            cout << "3. Edit Device-Specific Attributes\n4. Edit All\n";
            cout << "Choice: ";
            int choice;
            cin >> choice;
            
            if (choice == 1 || choice == 4) {
                string newName;
                cout << "New Name: ";
                cin.ignore();
                getline(cin, newName);
                device->setName(newName);
            }
            if (choice == 2 || choice == 4) {
                string newMfr;
                cout << "New Manufacturer: ";
                if (choice != 4) cin.ignore();
                getline(cin, newMfr);
                device->setManufacturer(newMfr);
            }
            if (choice == 3 || choice == 4) {
                device->editAttributes();
            }
            
            cout << "Device updated successfully.\n";
        } else {
            cout << "Device not found.\n";
        }
    }
    
    void listAllDevices() const {
        if (allDevices.empty()) {
            cout << "No devices in the system.\n";
            return;
        }
        
        cout << "\n" << string(70, '=') << "\n";
        cout << "ALL DEVICES IN SYSTEM\n";
        cout << string(70, '=') << "\n";
        for (size_t i = 0; i < allDevices.size(); i++) {
            cout << i + 1 << ". ID:" << allDevices[i]->getID() 
                 << " | " << allDevices[i]->getName() 
                 << " (" << allDevices[i]->getType() << ")"
                 << " | " << (allDevices[i]->getStatus() ? "Active" : "Inactive")
                 << " | " << (allDevices[i]->CheckConnection() ? "Connected" : "Disconnected")
                 << "\n";
        }
        cout << string(70, '=') << "\n";
    }
    
    void individualDeviceMenu() {
        if (allDevices.empty()) {
            cout << "No devices available.\n";
            return;
        }
        
        listAllDevices();
        cout << "\nEnter Device ID: ";
        int id;
        cin >> id;
        
        auto device = findDeviceByID(id);
        if (!device) {
            cout << "Device not found.\n";
            return;
        }
        
        while (true) {
            cout << "\n--- Device: " << device->getName() << " ---\n";
            cout << "1. View Info\n2. Activate\n3. Deactivate\n4. Interact\n";
            cout << "5. Check Connection\n0. Back\n";
            cout << "Choice: ";
            int choice;
            cin >> choice;
            
            switch(choice) {
                case 1: device->ViewInfo(); break;
                case 2: {
                    // Use Command Pattern
                    auto cmd = make_shared<ActivateCommand>(device);
                    commandInvoker.executeCommand(cmd);
                    break;
                }
                case 3: {
                    // Use Command Pattern
                    auto cmd = make_shared<DeactivateCommand>(device);
                    commandInvoker.executeCommand(cmd);
                    break;
                }
                case 4: {
                    // Use Command Pattern
                    auto cmd = make_shared<InteractCommand>(device);
                    commandInvoker.executeCommand(cmd);
                    break;
                }
                case 5: 
                    cout << device->getName() << " is " 
                         << (device->CheckConnection() ? "Connected" : "Disconnected") << "\n";
                    break;
                case 0: return;
                default: cout << "Invalid choice.\n";
            }
        }
    }
    
    void performActionOnAll() {
        if (allDevices.empty()) {
            cout << "No devices in the system.\n";
            return;
        }
        
        cout << "\n--- Perform Action on All Devices ---\n";
        cout << "1. View Info (All)\n2. Activate (All)\n";
        cout << "3. Deactivate (All)\n4. Interact (All)\n";
        cout << "Choice: ";
        int choice;
        cin >> choice;
        
        for (auto& device : allDevices) {
            switch(choice) {
                case 1: device->ViewInfo(); break;
                case 2: {
                    auto cmd = make_shared<ActivateCommand>(device);
                    commandInvoker.executeCommand(cmd);
                    break;
                }
                case 3: {
                    auto cmd = make_shared<DeactivateCommand>(device);
                    commandInvoker.executeCommand(cmd);
                    break;
                }
                case 4: {
                    auto cmd = make_shared<InteractCommand>(device);
                    commandInvoker.executeCommand(cmd);
                    break;
                }
                default: cout << "Invalid choice.\n"; return;
            }
        }
    }
    
    void viewConnectionStatus() const {
        cout << "\n--- CONNECTED DEVICES ---\n";
        int connectedCount = 0;
        for (const auto& device : allDevices) {
            if (device->CheckConnection()) {
                cout << "ID:" << device->getID() << " - " << device->getName() << "\n";
                connectedCount++;
            }
        }
        
        cout << "\n--- DISCONNECTED DEVICES ---\n";
        int disconnectedCount = 0;
        for (const auto& device : allDevices) {
            if (!device->CheckConnection()) {
                cout << "ID:" << device->getID() << " - " << device->getName() << "\n";
                disconnectedCount++;
            }
        }
        
        cout << "\nTotal Connected: " << connectedCount << "\n";
        cout << "Total Disconnected: " << disconnectedCount << "\n";
    }
    
    void changeConnectionStatus() {
        cout << "Enter Device ID to change connection: ";
        int id;
        cin >> id;
        
        auto device = findDeviceByID(id);
        if (device) {
            bool current = device->CheckConnection();
            device->setConnectionStatus(!current);
            cout << "Connection status changed to " 
                 << (device->CheckConnection() ? "Connected" : "Disconnected") << "\n";
        } else {
            cout << "Device not found.\n";
        }
    }
    
    void searchDevice() {
        cout << "\nSearch by:\n1. Device ID\n2. Device Name\n";
        cout << "Choice: ";
        int choice;
        cin >> choice;
        
        shared_ptr<Device> found = nullptr;
        
        if (choice == 1) {
            cout << "Enter Device ID: ";
            int id;
            cin >> id;
            found = findDeviceByID(id);
        } else if (choice == 2) {
            cout << "Enter Device Name: ";
            string name;
            cin.ignore();
            getline(cin, name);
            
            auto it = find_if(allDevices.begin(), allDevices.end(),
                [&name](const shared_ptr<Device>& d) { 
                    return d->getName().find(name) != string::npos; 
                });
            if (it != allDevices.end()) found = *it;
        }
        
        if (!found) {
            cout << "Device not found.\n";
            return;
        }
        
        cout << "\nDevice found!\n";
        while (true) {
            cout << "\n--- " << found->getName() << " ---\n";
            cout << "1. View Info\n2. Activate\n3. Deactivate\n4. Interact\n";
            cout << "5. Check Connection\n0. Back\n";
            cout << "Choice: ";
            int action;
            cin >> action;
            
            switch(action) {
                case 1: found->ViewInfo(); break;
                case 2: {
                    auto cmd = make_shared<ActivateCommand>(found);
                    commandInvoker.executeCommand(cmd);
                    break;
                }
                case 3: {
                    auto cmd = make_shared<DeactivateCommand>(found);
                    commandInvoker.executeCommand(cmd);
                    break;
                }
                case 4: {
                    auto cmd = make_shared<InteractCommand>(found);
                    commandInvoker.executeCommand(cmd);
                    break;
                }
                case 5: 
                    cout << found->getName() << " is " 
                         << (found->CheckConnection() ? "Connected" : "Disconnected") << "\n";
                    break;
                case 0: return;
                default: cout << "Invalid choice.\n";
            }
        }
    }
    
    void createRoom() {
        cout << "Enter Room Name: ";
        string roomName;
        cin.ignore();
        getline(cin, roomName);
        
        if (findRoomByName(roomName)) {
            cout << "Room already exists.\n";
            return;
        }
        
        rooms.push_back(Room(roomName));
        cout << "Room '" << roomName << "' created.\n";
    }
    
    void listRooms() const {
        if (rooms.empty()) {
            cout << "No rooms in the system.\n";
            return;
        }
        
        cout << "\n--- ROOMS ---\n";
        for (size_t i = 0; i < rooms.size(); i++) {
            cout << i + 1 << ". " << rooms[i].getName() 
                 << " (" << rooms[i].getDevices().size() << " devices)\n";
        }
    }
    
    void viewRoomDevices() {
        if (rooms.empty()) {
            cout << "No rooms available.\n";
            return;
        }
        
        listRooms();
        cout << "Select room number: ";
        int roomNum;
        cin >> roomNum;
        
        if (roomNum > 0 && roomNum <= static_cast<int>(rooms.size())) {
            rooms[roomNum - 1].listDevices();
        } else {
            cout << "Invalid room number.\n";
        }
    }
    
    void addDeviceToRoom(shared_ptr<Device> device) {
        if (rooms.empty()) {
            cout << "No rooms available. Create a room first.\n";
            return;
        }
        
        cout << "\n--- Available Rooms ---\n";
        for (size_t i = 0; i < rooms.size(); i++) {
            cout << i + 1 << ". " << rooms[i].getName() << "\n";
        }
        cout << "Select room number: ";
        int roomChoice;
        cin >> roomChoice;
        
        if (roomChoice > 0 && roomChoice <= static_cast<int>(rooms.size())) {
            rooms[roomChoice - 1].addDevice(device);
            cout << "Device added to " << rooms[roomChoice - 1].getName() << "\n";
        } else {
            cout << "Invalid room number.\n";
        }
    }
    
    void addDeviceToRoomMenu() {
        if (rooms.empty()) {
            cout << "No rooms available. Create a room first.\n";
            return;
        }
        
        listAllDevices();
        cout << "Enter Device ID to add: ";
        int id;
        cin >> id;
        
        auto device = findDeviceByID(id);
        if (!device) {
            cout << "Device not found.\n";
            return;
        }
        
        addDeviceToRoom(device);
    }
    
    void removeDeviceFromRoom() {
        if (rooms.empty()) {
            cout << "No rooms available.\n";
            return;
        }
        
        listRooms();
        cout << "Select room number: ";
        int roomNum;
        cin >> roomNum;
        
        if (roomNum <= 0 || roomNum > static_cast<int>(rooms.size())) {
            cout << "Invalid room number.\n";
            return;
        }
        
        rooms[roomNum - 1].listDevices();
        cout << "Enter Device ID to remove: ";
        int id;
        cin >> id;
        
        if (rooms[roomNum - 1].removeDevice(id)) {
            cout << "Device removed from room.\n";
        } else {
            cout << "Device not found in this room.\n";
        }
    }
    
    void activateRoomDevices() {
        if (rooms.empty()) {
            cout << "No rooms available.\n";
            return;
        }
        
        listRooms();
        cout << "Select room number: ";
        int roomNum;
        cin >> roomNum;
        
        if (roomNum > 0 && roomNum <= static_cast<int>(rooms.size())) {
            rooms[roomNum - 1].activateAll();
        } else {
            cout << "Invalid room number.\n";
        }
    }
    
    void deactivateRoomDevices() {
        if (rooms.empty()) {
            cout << "No rooms available.\n";
            return;
        }
        
        listRooms();
        cout << "Select room number: ";
        int roomNum;
        cin >> roomNum;
        
        if (roomNum > 0 && roomNum <= static_cast<int>(rooms.size())) {
            rooms[roomNum - 1].deactivateAll();
        } else {
            cout << "Invalid room number.\n";
        }
    }
    
    void duplicateRoom() {
        if (rooms.empty()) {
            cout << "No rooms to duplicate.\n";
            return;
        }
        
        listRooms();
        cout << "Select room number to duplicate: ";
        int roomNum;
        cin >> roomNum;
        
        if (roomNum <= 0 || roomNum > static_cast<int>(rooms.size())) {
            cout << "Invalid room number.\n";
            return;
        }
        
        Room& originalRoom = rooms[roomNum - 1];
        string newRoomName = originalRoom.getName() + "_copy";
        Room newRoom(newRoomName);
        
        // Use Prototype Pattern .......
        for (const auto& device : originalRoom.getDevices()) {
            int newID = getNextID();
            shared_ptr<Device> newDevice = device->clone(newID);
            newDevice->attachObserver(logger);
            allDevices.push_back(newDevice);
            newRoom.addDevice(newDevice);
        }
        
        rooms.push_back(newRoom);
        cout << "Room duplicated as '" << newRoomName << "' with " 
             << newRoom.getDevices().size() << " devices.\n";
    }
    
    void viewCommandHistory() {
        commandInvoker.showHistory();
    }
    
    void manageRooms() {
        while (true) {
            
            cout<<"\n------------------------------------------------";
            cout<<"\n|              ROOM MANAGEMENT                 |";
            cout<<"\n------------------------------------------------\n";

            cout << "1. Create Room\n2. List All Rooms\n3. View Devices in Room\n";
            cout << "4. Add Device to Room\n5. Remove Device from Room\n";
            cout << "6. Activate All Devices in Room\n7. Deactivate All Devices in Room\n";
            cout << "8. Duplicate Room\n0. Back\n";
            cout << "Choice: ";
            int choice;
            cin >> choice;
            
            switch(choice) {
                case 1: createRoom(); break;
                case 2: listRooms(); break;
                case 3: viewRoomDevices(); break;
                case 4: addDeviceToRoomMenu(); break;
                case 5: removeDeviceFromRoom(); break;
                case 6: activateRoomDevices(); break;
                case 7: deactivateRoomDevices(); break;
                case 8: duplicateRoom(); break;
                case 0: return;
                default: cout << "Invalid choice.\n";
            }
        }
    }
    
    void mainMenu() {
        while (true) {
            cout << "\n";
            cout<<"\t\t========================================";
            cout<<"\n\t\t|       Campus Management System       |";
            cout<<"\n\t\t========================================\n";
            
            cout<<"\n------------------------------------------------";
            cout<<"\n|            DEVICE MANAGEMENT                 |";
            cout<<"\n------------------------------------------------\n";
            cout << "1.  List All Devices\n";
            cout << "2.  Add New Device (Factory Pattern)\n";
            cout << "3.  Delete Device\n";
            cout << "4.  Edit Device\n";
            cout << "5.  Control Individual Device (Command Pattern)\n";
            cout << "6.  Perform Action on All Devices\n";
            cout << "7.  Search for Device\n";
            cout<<"\n------------------------------------------------";
            cout<<"\n|           CONNECTION MANAGEMENT              |";
            cout<<"\n------------------------------------------------\n";
            cout << "8.  View Connection Status\n";
            cout << "9.  Change Connection Status (Observer Pattern)\n";
            cout<<"\n------------------------------------------------";
            cout<<"\n|              ROOM MANAGEMENT                 |";
            cout<<"\n------------------------------------------------\n";
            cout << "10. Manage Rooms\n";
            
            cout<<"\n------------------------------------------------";
            cout<<"\n|                     SYSTEM                   |";
            cout<<"\n------------------------------------------------\n";            cout << "11. View Command History (Command Pattern)\n";
            cout << "12. Save Data (Strategy Pattern)\n";
            cout << "0.  Exit\n";
            cout<<"\n------------------------------------------------\n";

            cout << "\nChoice: ";
            
            int choice;
            cin >> choice;
            
            switch(choice) {
                case 1: listAllDevices(); break;
                case 2: addDevice(); break;
                case 3: deleteDevice(); break;
                case 4: editDevice(); break;
                case 5: individualDeviceMenu(); break;
                case 6: performActionOnAll(); break;
                case 7: searchDevice(); break;
                case 8: viewConnectionStatus(); break;
                case 9: changeConnectionStatus(); break;
                case 10: manageRooms(); break;
                case 11: viewCommandHistory(); break;
                case 12: saveToFile(); break;
                case 0:
                    saveToFile();
                    cout << "\nThank you for using Smart Campus System!\n";
                    return;
                default:
                    cout << "Invalid choice. Please try again.\n";
            }
        }
    }
};

//Main_function.......

int main() {
    // Singleton Pattern: Get single instance
    SmartCampusSystem& system = SmartCampusSystem::getInstance();
    system.mainMenu();
    return 0;
}